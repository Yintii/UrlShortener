// app/javascript/controllers/index.js
import { application } from "./application"
import NavbarController from "./navbar_controller"

application.register("navbar", NavbarController);
