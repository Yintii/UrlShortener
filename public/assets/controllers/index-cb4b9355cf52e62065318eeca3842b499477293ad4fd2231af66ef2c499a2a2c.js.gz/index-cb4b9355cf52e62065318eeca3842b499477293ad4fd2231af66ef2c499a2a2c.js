// app/javascript/controllers/index.js
import { application } from "./application.js"
import NavbarController from "./navbar_controller.js"

application.register("navbar", NavbarController);
